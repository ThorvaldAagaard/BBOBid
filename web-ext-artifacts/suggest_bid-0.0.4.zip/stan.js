const fetch = require("node-fetch");
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;

var createCORSRequest = function (method, url) {
    var xhr2 = new XMLHttpRequest();
    if ("withCredentials" in xhr2) {
        // Most browsers.
        xhr2.open(method, url, true);
    } else if (typeof XDomainRequest != "undefined") {
        // IE8 & IE9
        xhr2 = new XDomainRequest();
        xhr2.open(method, url);
    } else {
        // CORS not supported.
        xhr2 = null;
    }
    return xhr2;
};

function getSystemsAsync(url) {

    return new Promise(function (resolve, reject) {
        var method = 'GET';
        var xhr = createCORSRequest(method, url);

        xhr.onload = function () {
            if (this.status >= 200 && this.status < 300) {
                resolve(xhr.responseText);
            } else {
                reject({
                    status: this.status,
                    statusText: xhr.statusText
                });
            }
        };
        xhr.onerror = function () {
            reject({
                status: this.status,
                statusText: xhr.statusText
            });
        };

        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        xhr.send();
    });
}


fetch('https://bidding.snippen.dk/download/Test.txt').then(response => response.text())
    .then(textString => {
        //console.log(textString);
    });
    
getSystemsAsync('https://bidding.snippen.dk/Convention.asp?id=47').then((resp) => {
    console.log("Response:\n " + resp)
})
