var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;



function test() {
	var createCORSRequest = function (method, url) {
		var xhr2 = new XMLHttpRequest();
		if ("withCredentials" in xhr2) {
			// Most browsers.
			xhr2.open(method, url, true);
		} else if (typeof XDomainRequest != "undefined") {
			// IE8 & IE9
			xhr2 = new XDomainRequest();
			xhr2.open(method, url);
		} else {
			// CORS not supported.
			xhr2 = null;
		}
		return xhr2;
	};

	var url = 'https://bidding.snippen.dk/PossibleSystems.asp';
	var method = 'OPTIONS';
	var xhr = createCORSRequest(method, url);

	xhr.onload = function () {
		console.log(xhr)
	};

	xhr.onerror = function () {
		console.log(xhr)
	};

	xhr.send();	
}

test();